package br.edu.uerr.loja;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DemoApplicationTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
