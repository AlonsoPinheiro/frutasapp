insert into empresa  (nome, cnpj, responsavel, telefone, email) values
('banana 1','01.001.001/0001-12','Francisco','(95)99123-2323','banana@lojas.com'),
('banana 2','11.001.001/0001-13','João','(95)99123-2323','banana@lojas.com'),
('banana 3','21.001.001/0001-14','Maria','(95)99123-2323','banana@lojas.com'),
('banana 4','31.001.001/0001-15','Raimunda','(95)99123-2323','banana@lojas.com'),
('banana 5','41.001.001/0001-16','Tiago','(95)99123-2323','banana@lojas.com'),
('banana 6','51.001.001/0001-17','Carlos','(95)99123-2323','banana@lojas.com');
insert into fornecedor  (nome, cnpj, responsavel, telefone, email) values
('Coca-cola','01.001.001/0001-12','Francisco','(95)99123-2323','banana@lojas.com'),
('Skol','11.001.001/0001-13','João','(95)99123-2323','banana@lojas.com'),
('Gavião','21.001.001/0001-14','Maria','(95)99123-2323','banana@lojas.com'),
('DB','31.001.001/0001-15','Raimunda','(95)99123-2323','banana@lojas.com'),
('Atacadão','41.001.001/0001-16','Tiago','(95)99123-2323','banana@lojas.com'),
('BigAmigão','51.001.001/0001-17','Carlos','(95)99123-2323','banana@lojas.com');